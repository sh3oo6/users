
from Dex4 import *


@led.on(events.NewMessage(pattern=r'x', outgoing=True))
async def execute_script2(events):
    await events.edit('okay')
    await led.send_message('botfather', '/newbot')
    sleep(1)
    await led.send_message('botfather', 'Dex')
    x = 0
    while True:
        i=0
        while True:
            i += +1
            x += +1
            u = str(''.join((random.choice(uss) for i in range(2))))
            e = str(''.join((random.choice(rr) for i in range(1))))
            user = e + u + 'bot'
            if i == 150:
                if 'off' in open('check.txt', 'r').read() :
                    print('Godd+++++++++++++++++++++++++++++++')
                s= open('check.txt', 'w')
                s.write(str(x))
                s.close()
                sleep(1)
                break
            sleep(0.165)
            req = requests.get(f"https://t.me/{user}")
            if req.text.find('If you have <strong>Telegram</strong>, you can contact <a class="tgme_username_link"') >= 0:
                p = requests.get(f"https://fragment.com/username/{user}").text
                sleep(0.3)
                if 'Unavailable' in p:
                    try:
                        z = await led.send_message('botfather', user)
                        if z:

                            await led.send_message('botfather', '/newbot')
                            sleep(1)
                            await led.send_message('botfather', 'Dex')

                    except Exception:
                        pass
            else:
                pass
                print('me',(f"NOOO : {user}" + ' ' + str(i) + " " + str(x)))



@led.on(events.NewMessage(pattern=r't', outgoing=True))
async def execute_script1(event):
    user = event.message.message[2:]
    x = 0
    for t in range(3333):
        i = 0
        for t in range(3333):
            i += +1
            x += +1
            if i == 100:
                s = await open('check.txt', 'w')
                s.write(str(x))
                s.close()
                await asyncio.sleep(1)
                break
            req = requests.get(f"https://t.me/{user}")
            if req.text.find('If you have <strong>Telegram</strong>, you can contact <a class="tgme_username_link"') >= 0:
                take = await led(UpdateUsernameRequest(user))
                if take :
                    requests.post(f"""https://api.telegram.org/bot{token}/sendmessage?chat_id={id}&text=« new hutting """)
            else:
                print(f"NOOO : {user}" + ' ' + str(i)+" "+str(x))


@led.on(events.NewMessage(pattern=r'e', outgoing=True))
async def execute_script3(event):
    s = open('main.txt', 'w').write('off')
    await event.edit('okay')
    await asyncio.sleep(100)
@led.on(events.NewMessage(pattern=r'p', outgoing=True))
async def execute_script4(event):
    s = open('check.txt', 'r').read()
    await event.edit(s)


async def spam_function(event, sandy, cat, sleeptimem, sleeptimet, DelaySpam=False, catutils=None):
    hmm = base64.b64decode("QUFBQUFGRV9vWjVYVE5fUnVaaEtOdw==")
    counter = int(cat[0])
    if len(cat) == 2:
        spam_message = str(cat[1])
        for _ in range(counter):
            if event.reply_to_msg_id:
                await sandy.reply(spam_message)
            else:
                await event.client.send_message(event.chat_id, spam_message)
            await asyncio.sleep(sleeptimet)
    elif event.reply_to_msg_id and sandy.media:
        for _ in range(counter):
            sandy = await event.client.send_file(
                event.chat_id, sandy, caption=sandy.text
            )
            await catutils.unsavegif(event, sandy)
            await asyncio.sleep(sleeptimem)
    elif event.reply_to_msg_id and sandy.text:
        spam_message = sandy.text
        for _ in range(counter):
            await event.client.send_message(event.chat_id, spam_message)
            await asyncio.sleep(sleeptimet)


@led.on(events.NewMessage(outgoing=True, pattern="v"))
async def spammer(event):
    reply = await event.get_reply_message()
    input_str = "".join(event.text.split(maxsplit=1)[1:]).split(" ", 2)
    sleeptimet = sleeptimem = float(input_str[0])
    cat = input_str[1:]
    await event.delete()
    await spam_function(event, reply, cat, sleeptimem, sleeptimet, DelaySpam=True)



try:
    led.run_until_disconnected()
except Exception:
    pass