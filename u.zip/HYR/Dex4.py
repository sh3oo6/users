from time import sleep
import requests
from telethon.tl.functions.account import UpdateUsernameRequest
from telethon.sync import TelegramClient , functions , events
import asyncio
import random
import os
import base64
id='5229914714'
token='6183317549:AAGB5jAoTSGSc0M0Y_8WR7kEa7oYbyjshM0'
led=TelegramClient('3z', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
led.start()
led.send_message('me','ok')
uss='qwertyuioplkjhgfdsazxcvbnm1234567890'
rr='qwertyuioplkjhgfdsazxcvbnm'
