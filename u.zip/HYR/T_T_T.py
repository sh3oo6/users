import random , requests
from time import sleep
from telethon.sync import *
from telethon.errors.rpcerrorlist import FloodError
from telethon.tl.functions.users import GetFullUserRequest
led=TelegramClient('3z', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
led.start()
id='6140911166'
token='6669937003:AAFNvcxK7qa9ujvq2A2fUBG35ZBZUtbkFoQ'
uss='qwertyuioplkjhgfdsazxcvbnm1234567890'
rr='qwertyuioplkjhgfdsazxcvbnm'
def sd(B):
    requests.post(f'https://api.telegram.org/bot{token}/sendMessage?chat_id={id}&text={B}')
def T():
    w1 = open('2022.txt', 'a')
    w2 = open('2023.txt', 'a')
    w3 = open('2023_new.txt', 'a')
    r1 = open('2022.txt', 'r')
    r2 = open('2023.txt', 'r')
    r3 = open('2023_new.txt', 'r')
    x = 0
    while True:
        i = 0
        while True:
            i += +1
            x += +1
            u3 = str(''.join((random.choice(uss) for i in range(1))))
            u2 = str(''.join((random.choice(uss) for i in range(1))))
            u1 = str(''.join((random.choice(rr) for i in range(1))))
            user = u1 + '_' + u2 + '_' + u3
            print('@'+user)
            if i == 100:
                sleep(2)
                break
            sleep(0.05)
            req = requests.get(f"https://t.me/{user}")
            if req.text.find('Send Message') >= 0:
                if req.text.find(
                        'If you have <strong>Telegram</strong>, you can contact <a class="tgme_username_link"') >= 0:
                    pass
                else:
                    try:result = led(GetFullUserRequest(user))
                    except FloodError as f:
                        ff=(str(f)[10:14])
                        sleep(int(ff)+300)
                    try:
                        if result:
                            use = result.users[0]
                            last_seen = use.status.was_online
                            us = (str(last_seen)[5:7])
                            if (str(last_seen)[:4]) == "2022":
                                if user in r1.read():
                                    r1.close()
                                    pass
                                else:
                                    w1.write('\n'+user)
                                    w1.close()
                                    sd(user)
                            elif (str(last_seen)[:4]) == "2023":
                                ii = (str(last_seen)[6:7])
                                if int(ii) <= 1 :
                                    if user in r2.read():
                                        r2.close()
                                        pass
                                    else:
                                        w2.write('\n'+user)
                                        w2.close()
                                        sd(user)
                                elif int(ii) <= 6 :
                                    if user in r3.read():
                                        r3.close()
                                        pass
                                    else:
                                        w3.write('\n'+user)
                                        w3.close()
                                        sd(user)
                    except:
                        pass
T()