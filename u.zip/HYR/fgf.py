w3 = open('2023_new.txt', 'a')
if 'i' in w3.read():
    pass
else:
    w3.write('\ngg')
